from setuptools import setup

setup(name='galaxy_mgp',
      version='0.1.2',
      description='The plathora distanced',
      url='http://github.com/mgpradeepa/py_pip',
      author='MGP',
      author_email='mgpradeepa@gmail.com',
      license='',
      packages=['galaxy_mgp'],
      zip_safe=False)
